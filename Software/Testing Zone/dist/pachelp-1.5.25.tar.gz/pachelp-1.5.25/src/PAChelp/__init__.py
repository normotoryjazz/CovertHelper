if __name__ == "__main__":
    from PAChelp.cli import app
    app()