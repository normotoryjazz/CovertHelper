if __name__ == "__main__":
    from CovertHelp.cli import app
    app()